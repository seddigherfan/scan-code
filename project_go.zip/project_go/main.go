package main

import (
	"bufio"
	"fmt"
	"net"
	"strings"
	"sync"
	"time"
)

// IPRange مدیریت محدوده IP
type IPRange struct {
	Start net.IP
	End   net.IP
}

// NewIPRange مقداردهی اولیه محدوده IP
func NewIPRange(start, end string) *IPRange {
	return &IPRange{
		Start: net.ParseIP(start),
		End:   net.ParseIP(end),
	}
}

// NextIP دریافت IP بعدی در محدوده
func (r *IPRange) NextIP(ip net.IP) net.IP {
	newIP := make(net.IP, len(ip))
	copy(newIP, ip)

	for i := len(newIP) - 1; i >= 0; i-- {
		newIP[i]++
		if newIP[i] > 0 {
			break
		}
	}
	return newIP
}

// PortScanner برای اسکن پورت‌های باز
type PortScanner struct {
	Ports []int
}

// NewPortScanner مقداردهی اولیه اسکنر پورت
func NewPortScanner(ports []int) *PortScanner {
	return &PortScanner{Ports: ports}
}

// Scan اسکن پورت‌های باز روی یک IP
func (ps *PortScanner) Scan(ip net.IP) []int {
	openPorts := []int{}
	for _, port := range ps.Ports {
		address := fmt.Sprintf("%s:%d", ip, port)
		conn, err := net.DialTimeout("tcp", address, 2*time.Second)
		if err == nil {
			openPorts = append(openPorts, port)
			conn.Close()
		}
	}
	return openPorts
}

// BannerGrabber دریافت بنر از پورت‌های مشخص
type BannerGrabber struct{}

// GetBanner دریافت بنر از یک پورت خاص
func (bg *BannerGrabber) GetBanner(ip net.IP, port int) (string, error) {
	address := fmt.Sprintf("%s:%d", ip, port)
	conn, err := net.DialTimeout("tcp", address, 3*time.Second)
	if err != nil {
		return "", err
	}
	defer conn.Close()

	conn.SetReadDeadline(time.Now().Add(3 * time.Second))
	reader := bufio.NewReader(conn)
	banner, err := reader.ReadString('\n')
	if err != nil {
		return "", err
	}
	return strings.TrimSpace(banner), nil
}

// Scanner مدیریت کل فرآیند اسکن با استفاده از Worker Pool
type Scanner struct {
	IPRange       *IPRange
	PortScanner   *PortScanner
	BannerGrabber *BannerGrabber
	WorkerCount   int
	IPJobs        chan net.IP
	Mutex         sync.Mutex
	WG            sync.WaitGroup
}

// NewScanner مقداردهی اولیه اسکنر
func NewScanner(ipRange *IPRange, portScanner *PortScanner, bannerGrabber *BannerGrabber, workerCount int) *Scanner {
	return &Scanner{
		IPRange:       ipRange,
		PortScanner:   portScanner,
		BannerGrabber: bannerGrabber,
		WorkerCount:   workerCount,
		IPJobs:        make(chan net.IP, workerCount),
	}
}

// ScanIP اسکن یک IP مشخص
func (s *Scanner) ScanIP(ip net.IP) {
	defer s.WG.Done()

	openPorts := s.PortScanner.Scan(ip)
	if len(openPorts) > 0 {
		s.Mutex.Lock()
		fmt.Printf("IP: %s has open ports: %v\n", ip, openPorts)
		s.Mutex.Unlock()

		// بررسی دریافت بنر از پورت‌های خاص
		for _, port := range openPorts {
			if port == 21 || port == 25 {
				banner, err := s.BannerGrabber.GetBanner(ip, port)
				if err == nil {
					fmt.Printf("IP: %s, Port: %d, Banner: %s\n", ip, port, banner)
				} else {
					fmt.Printf("IP: %s, Port: %d, Error getting banner: %s\n", ip, port, err)
				}
			}
		}
	} else {
		s.Mutex.Lock()
		fmt.Printf("IP: %s has no open ports.\n", ip)
		s.Mutex.Unlock()
	}
}

// worker اجرای فرآیند اسکن برای هر IP
func (s *Scanner) worker() {
	for ip := range s.IPJobs {
		s.ScanIP(ip)
	}
}

// Run اجرای فرآیند اسکن با Worker Pool
func (s *Scanner) Run() {
	// راه‌اندازی Workerها
	for i := 0; i < s.WorkerCount; i++ {
		s.WG.Add(1)
		go func() {
			defer s.WG.Done()
			s.worker()
		}()
	}

	// ارسال IPها به کانال پردازش
	for ip := s.IPRange.Start; !ip.Equal(s.IPRange.End); ip = s.IPRange.NextIP(ip) {
		s.WG.Add(1)
		s.IPJobs <- ip
	}

	// بستن کانال پس از ارسال تمام IPها
	close(s.IPJobs)

	// انتظار برای اتمام همه Goroutine‌ها
	s.WG.Wait()
	fmt.Println("Scanning completed!")
}

// main اجرای برنامه
func main() {
	ipRange := NewIPRange("127.0.0.0", "127.0.0.255")
	portScanner := NewPortScanner([]int{21, 25, 80, 443, 22, 3389, 8080, 143, 587, 465})
	bannerGrabber := &BannerGrabber{}
	workerCount := 10

	scanner := NewScanner(ipRange, portScanner, bannerGrabber, workerCount)
	scanner.Run()
}
